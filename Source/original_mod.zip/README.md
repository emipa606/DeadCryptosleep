# Frontier Developments Dead Cryptosleep

## Features

Allows hauling corpses to cryptosleep caskets.

#### Languages
- English

## Contributions

Contributions will be credited to the authors. Merged contributions will be owned by the mod itself (important for future license changes, but we anticipate that never happening).

### Localization

We want to support as many languages as possible. If you would like to submit translations please submit them as pull request.
 