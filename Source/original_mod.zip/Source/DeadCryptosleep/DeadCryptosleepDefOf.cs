using RimWorld;
using Verse;

namespace FrontierDevelopments.DeadCryptosleep
{
    [DefOf]
    public class DeadCryptosleepDefOf
    {
        public static JobDef HaulCorpseToCryptosleepCasket;
        public static DesignationDef Deadcryptosleep_Haul;
        public static ThingDef CryptosleepCasket;
    }
}